#include<stdio.h>
#include<stdlib.h>
#include<graph.h>
#include<math.h>
#include<time.h>
#include"dimensions.h"
#include"partie.h"

int main(void) {

/*Nous avons ici l'initialisation de toutes les variables qui vont nous servir dans la fonction principale.*/
	int x, y = 0;			/*--> x et y sont les variables qui mémoriseront la position en largeur et hauteur du pixel où la souris à cliquée.*/
	int a = 1500, b = 850;		/*--> a et b sont les valeurs respective en largeur et hauteur de la fenêtre.*/
	int c, d, e, f; 
	int dimx, dimy;			/*--> Ce sont les deux variables qui contiendront la taille de chaque image, x pour la largeur, et y pour la hauteur*/ 
	int ligne, colonne;		/*--> Ces variables contiennent le nombre de lignes et colonnes voulu par l'utilisateur.*/
	int ok = 0, k;			/*Ce sont deux variables de test*/


/*Cette boucle while sert à répéter le programme tant que l'utilisateur n'a pas demandé à le quitter en fin de partie.*/
	while (ok != XK_q) {
		k = 0;
		InitialiserGraphique();			/*--> Nous initialisons ici la fenêtre pour l'affichage graphique.*/
		CreerFenetre(0, 0, a, b);


/*Voici quelques lignes pour l'affichage du menu.*/
		EcrireTexte(10, 100, "Choississez une images parmis les apercus suivants :", 2);
		ChargerImage("Japon.png", 10, 200, 0, 0, 410, 490);
		ChargerImage("Seatle.jpg", 430, 200, 150, 0, 500, 490);
		ChargerImage("Pont.jpg", 940, 200, 0, 0, 550, 490);
		EcrireTexte(90, 790, "Niveau facile, petite image.", 1);
		EcrireTexte(550, 790, "Niveau moyen, grande image.", 1);
		EcrireTexte(1090, 790, "Niveau difficile, sans couleur.", 1);
	

/*La boucle qui suit nous sert à faire patienter le programme, tant que aucune des images n'a été cliquée.*/
		while (k == 0) {
			x = 0;
			_X = 0;
			while (x == 0) {
				SourisCliquee();		/*--> Nous vérifions ici si la souris est cliquée, si elle l'est, les variables _X et _Y vont automatiquement changer et prendre les valeurs de la postion du pixel cliqué, respectivement en largeur et hauteur.*/
				if (_X != x) {
					x = _X;
					y = _Y;
				}
			}
		
			if ((10 <= x) && (x <= 420) && (200 <= y) && (y <= 690)) {		/*Cette condition vérifie si le clique se trouve dans les coordonnées qui correspondent à la première image. On exécute ensuite le code du fichier jeu, qui permet alors de jouer avec la celle-ci.*/
				k = 1;
				ligne = lignes();
				colonne = colonnes();
				c = trunc(419 / colonne);	/*--> c et d prennent les valeurs que nous voulons donner comme étant les tailles en pixels d'un carreau du Taquin.*/
				d = trunc(492 / ligne);
				e = 881;			/*--> e et f sont des valeurs arbitraires choisies pour afficher le coin en haut à gauche du plateau de Taquin.*/
				f = 200;
				dimx = 419;
				dimy = 492;

				EffacerEcran(CouleurParNom("White"));
				ChargerImage("Japon.png", e, f, 0, 0, dimx, dimy);
				ok = jeu(c, d, ligne, colonne, e, f, dimx, dimy);		/*--> Cette ligne lance le fichier qui permet d'exécuter la partie. Suivant la valeur renvoyée, une partie est relancée ou non.*/
				EffacerEcran(CouleurParNom("White"));
			}
		
			else if ((430 <= x) && (x <= 930) && (200 <= y) && (y <= 690)) {	/*Pareil pour la deuxième image.*/
				k = 1;
				ligne = lignes();
				colonne = colonnes();
				c = trunc (1024 / colonne);
				d = trunc (548 / ligne);
				e = 405;
				f = 200;
				dimx = 1024;
				dimy = 548;
		
				EffacerEcran(CouleurParNom("White"));		
				ChargerImage("Seatle.jpg", e, f, 0, 0, dimx, dimy);
				ok = jeu(c, d, ligne, colonne, e, f, dimx, dimy);
				EffacerEcran(CouleurParNom("White"));
			}
		
			
			else if ((940 <= x) && (x <= 1490) && (200 <= y) && (y <= 690)) {	/*Pareil pour la troisième image.*/
				k = 1;
				ligne = lignes();
				colonne = colonnes();
				c = trunc (900 / colonne);
				d = trunc (595 / ligne);
				e = 525;
				f = 180;
				dimx = 900;
				dimy = 595;
		
				EffacerEcran(CouleurParNom("White"));		
				ChargerImage("Pont.jpg", e, f, 0, 0, dimx, dimy);
				ok = jeu(c, d, ligne, colonne, e, f, dimx, dimy);
				EffacerEcran(CouleurParNom("White"));
			}
		}
	}
	FermerGraphique();	/*--> Voici la fin du programme et donc, sa dernière fonction qui ferme la fenêtre.*/
	return EXIT_SUCCESS;
}
