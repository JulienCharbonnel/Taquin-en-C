#ifndef DIMENSIONS_H
#define DIMENSIONS_H

int lignes();
int colonnes();

#endif /* DIMENSIONS_H */
