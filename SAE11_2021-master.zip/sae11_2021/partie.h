#ifndef PARTIE_H
#define PARTIE_H

int jeu(int, int, int, int, int, int, int, int);

#endif /* PARTIE_H */
