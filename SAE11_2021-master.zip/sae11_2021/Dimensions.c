#include<stdio.h>
#include<stdlib.h>
#include<graph.h>
#include<time.h>
#include<math.h>
#include"dimensions.h"

int lignes() {
	int ligne = 0;
	int x, y;

	EffacerEcran(CouleurParNom("White"));
	EcrireTexte(10, 100, "Pour le nombre de lignes, cliquez sur une des cases :", 2);

	ChargerImage("3.jpeg", 10, 200, 0, 0, 225, 225);
	ChargerImage("4.jpeg", 455, 200, 0, 0, 225, 225);
	ChargerImage("5.jpeg", 900, 200, 0, 0, 225, 225);
	ChargerImage("6.jpeg", 10, 545, 0, 0, 225, 225);
	ChargerImage("7.jpeg", 455, 545, 0, 0, 225, 225);
	ChargerImage("8.jpeg", 900, 545, 0, 0, 225, 225);

	while (ligne == 0) {
		x = 0;
		y = 0;
		_X = 0;
		_Y = 0;
		while (x == 0) {
			SourisCliquee();
			if (_X != x) {
				x = _X;
				y = _Y;
			}
		}
	
		if ((10 <= x) && (x <= 235) && (200 <= y) && (y <= 425)) {
			ligne = 3;
		}
		else if ((455 <= x) && (x <= 680) && (200 <= y) && (y <= 425)) {
			ligne = 4;
		}
		else if ((900 <= x) && (x <= 1125) && (200 <= y) && (y <= 425)) {
			ligne = 5;
		}
		else if ((10 <= x) && (x <= 235) && (545 <= y) && (y <= 770)) {
			ligne = 6;
		}
		else if ((455 <= x) && (x <= 680) && (545 <= y) && (y <= 770)) {
			ligne = 7;
		}
		else if ((900 <= x) && (x <= 1125) && (545 <= y) && (y <= 770)) {
			ligne = 8;
		}
	}
	return ligne;
}

int colonnes() {
	int colonne = 0;
	int x, y;

	EffacerEcran(CouleurParNom("White"));
	EcrireTexte(10, 100, "Pour le nombre de colonne, cliquez sur une des cases :", 2);

	ChargerImage("3.jpeg", 10, 200, 0, 0, 225, 225);
	ChargerImage("4.jpeg", 455, 200, 0, 0, 225, 225);
	ChargerImage("5.jpeg", 900, 200, 0, 0, 225, 225);
	ChargerImage("6.jpeg", 10, 545, 0, 0, 225, 225);
	ChargerImage("7.jpeg", 455, 545, 0, 0, 225, 225);
	ChargerImage("8.jpeg", 900, 545, 0, 0, 225, 225);
	
	while (colonne == 0) {
		x = 0;
		y = 0;
		_X = 0;
		_Y = 0;
		while (x == 0) {
			SourisCliquee();
			if (_X != x) {
				x = _X;
				y = _Y;
			}
		}
		if ((10 <= x) && (x <= 235) && (200 <= y) && (y <= 425)) {
			colonne = 3;
		}
		else if ((455 <= x) && (x <= 680) && (200 <= y) && (y <= 425)) {
			colonne = 4;
		}
		else if ((900 <= x) && (x <= 1125) && (200 <= y) && (y <= 425)) {
			colonne = 5;
		}
		else if ((10 <= x) && (x <= 235) && (545 <= y) && (y <= 770)) {
			colonne = 6;
		}
		else if ((455 <= x) && (x <= 680) && (545 <= y) && (y <= 770)) {
			colonne = 7;
		}
		else if ((900 <= x) && (x <= 1125) && (545 <= y) && (y <= 770)) {
			colonne = 8;
		}
	}
	return colonne;
}
