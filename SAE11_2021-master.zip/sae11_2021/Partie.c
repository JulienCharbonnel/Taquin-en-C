#include<stdio.h>
#include<stdlib.h>
#include<graph.h>
#include<math.h>
#include<time.h>
#include"partie.h"

int jeu(int c, int d, int ligne, int colonne, int e, int f, int dimx, int dimy) {
	int i, j, n = 0, m, a, b, t = e, u = f, p, k, l, compt = 0, coup = 0;
	int tab[ligne][colonne], tab2[ligne][colonne];
	char nbr[10];
	srand(time(NULL));

	for (j = 0; j < ligne; j += 1) {
		for (i = 0; i < colonne; i += 1) {
			tab[j][i] = n;
			tab2[j][i] = n;
			n += 1;
		}
	}

	p = rand()%101;
	for (n = 0; n < 1000; n += 1) {
		for (j = 0; j < ligne; j += 1) {
			for (i = 0; i < colonne; i += 1) {
				if (tab[j][i] == 0) {
					if ((j == 0) || (j == (ligne-1))) {
						if ((i == 0) || (i == (colonne-1))) {
							p = (p%2)+1;
							if ((p == 1) && (i == 0)) {
								tab[j][i] = tab[j][i+1];
								tab[j][i+1] = 0;
							} else if ((p == 1) && (i == (colonne-1))) {
								tab[j][i] = tab[j][i-1];
								tab[j][i-1] = 0;
							} else if ((p == 2) && (j == 0)) {
								tab[j][i] = tab[j+1][i];
								tab[j+1][i] = 0;
							} else {
								tab[j][i] = tab[j-1][i];
								tab[j-1][i] = 0;
							}
						} else {
							p = (p%3)+1;
							if (p == 1) {
								tab[j][i] = tab[j][i-1];
								tab[j][i-1] = 0;
							} else if (p == 3) {
								tab[j][i] = tab[j][i+1];
								tab[j][i+1] = 0;
							} else if ((p == 2) && (j == 0)) {
								tab[j][i] = tab[j+1][i];
								tab[j+1][i] = 0;
							} else {
								tab[j][i] = tab[j-1][i];
								tab[j-1][i] = 0;
							}
						}
					} else if ((i == 0) || (i == (colonne-1))) {
						p = (p%3)+1;
						if (p == 1) {
							tab[j][i] = tab[j-1][i];
							tab[j-1][i] = 0;
						} else if (p == 3) {
							tab[j][i] = tab[j+1][i];
							tab[j+1][i] = 0;
						} else if ((p == 2) && (i == 0)) {
							tab[j][i] = tab[j][i+1];
							tab[j][i+1] = 0;
						} else {
							tab[j][i] = tab[j][i-1];
							tab[j][i-1] = 0;
						}
					} else {
						p = (p%4)+1;
						if (p == 1) {
						EcrireTexte(200, 800, nbr, 1);
							tab[j][i] = tab[j][i-1];
							tab[j][i-1] = 0;
						} else if (p == 2) {
							tab[j][i] = tab[j-1][i];
							tab[j-1][i] = 0;
						} else if (p == 3) {
							tab[j][i] = tab[j][i+1];
							tab[j][i+1] = 0;
						} else {
							tab[j][i] = tab[j+1][i];
							tab[j+1][i] = 0;
						}
					}
					p = rand()%101;
				}
			}
		}
	}

	CopierZone(0, 1, e, f, dimx, dimy, 0, 0);
	EffacerEcran(CouleurParNom("White"));
	
	if (dimx == 1024) {
		ChargerImage("Seatle.jpg", 200, 200, 0, 0, dimx, dimy);
		CopierZone(0, 1, 200, 200, dimx, dimy, 0, 0);
		EffacerEcran(CouleurParNom("White"));
	} else if (dimx == 900) {
		ChargerImage("Pont.jpg", 200, 200, 0, 0, dimx, dimy);
		CopierZone(0, 1, 200, 200, dimx, dimy, 0, 0);
		EffacerEcran(CouleurParNom("White"));
	}

	for (m = 0; m < ligne; m += 1) {
		for (n = 0; n < colonne; n += 1) {
			if (tab[m][n] != 0) {
				a = 0;
				b = 0;
				for (j = 0; j < ligne; j += 1) {
					for (i = 0; i < colonne; i += 1) {
						if (tab[m][n] == tab2[j][i]) {
							if ((i != colonne) && (j != ligne)) {
								CopierZone(1, 0, a, b, c, d, e, f);
							} else if ((i == colonne) && (j != ligne)){
								CopierZone(1, 0, a, b, (dimx - ((i-1)*c)), d, e, f);
							} else if ((i != colonne) && (j == ligne)) {
								CopierZone(1, 0, a, b, c, (dimy - ((j-1)*d)), e, f);
							} else {
								CopierZone(1, 0, a, b, (dimx - ((i-1)*c)), (dimy - ((j-1)*d)), e, f);
							}
						}
						a = a + c;
					}
					b = b + d;
					a = 0;
				}
			}
			e = e + c + 10;
		}
		f = f + d + 10;
		e = t;
	}

	e = t;
	f = u;

	if (dimx == 419) {
		ChargerImage("Japon.png", 200, 200, 0, 0, dimx, dimy);
		CopierZone(0, 1, 200, 200, dimx, dimy, 0, 0);
		EcrireTexte(150, 800, "Nombre de coups : ", 1);
		sprintf(nbr, "%d", coup);
		EcrireTexte(350, 800, nbr, 1);
		for (j = 0; j < ligne; j += 1) {
			for (i = 0; i < colonne; i += 1) {
				if ((tab[j][i] != tab2[j][i]) || (compt = 1)) {
					compt = 0;
					p = Touche();
					if (p == XK_Left) {
						for (m = 0; m < ligne; m += 1) {
							for (n = 0; n < colonne; n += 1) {
								if ((tab[m][n] == 0) && (n != (colonne-1))) {
									tab[m][n] = tab[m][n+1];
									tab[m][n+1] = 0;
									n = n + 1;
									coup += 1;
								}
							}

						}

					} else if (p == XK_Up) {
						for (m = 0; m < ligne; m += 1) {
							for (n = 0; n < colonne; n += 1) {
								if ((tab[m][n] == 0) && (m != (ligne-1))) {
									tab[m][n] = tab[m+1][n];
									tab[m+1][n] = 0;
									m = m + 1;
									coup += 1;
								}
							}
						}
					} else if (p == XK_Right) {
						for (m = 0; m < ligne; m += 1) {
							for (n = 0; n < colonne; n += 1) {
								if ((tab[m][n] == 0) && (n != 0)) {
									tab[m][n] = tab[m][n-1];
									tab[m][n-1] = 0;
									coup += 1;
								}
							}
						}
					} else if (p == XK_Down) {
						for (m = 0; m < ligne; m += 1) {
							for (n = 0; n < colonne; n += 1) {
								if ((tab[m][n] == 0) && (m != 0)) {
									tab[m][n] = tab[m-1][n];
									tab[m-1][n] = 0;
									coup += 1;
								}
							}
						}
					}
					EffacerEcran(CouleurParNom("White"));
					CopierZone(1, 0, 0, 0, dimx, dimy, 200, 200);
					EcrireTexte(150, 800, "Nombre de coups : ", 1);
					sprintf(nbr, "%d", coup);
					EcrireTexte(350, 800, nbr, 1);
					for( m = 0; m < ligne; m += 1) {
						for (n = 0; n < colonne; n += 1) {
							if (tab[m][n] != 0) {
								a = 0;
								b = 0;
								for (l = 0; l < ligne; l += 1) {
									for (k = 0; k < colonne; k += 1) {
										if (tab[m][n] == tab2[l][k]) {
											if ((k != colonne) && (l != ligne)) {
												CopierZone(1, 0, a, b, c, d, e, f);
											} else if ((k == colonne) && (l != ligne)) {
												CopierZone(1, 0, a, b, (dimx - ((k-1)*c)), d, e, f);
											} else if ((k != colonne) && (l == ligne)) {
												CopierZone(1, 0, a, b, c, (dimy - ((l-1)*d)), e, f);
											} else {
												CopierZone(1, 0, a, b, (dimx - ((k-1)*c)), (dimy - ((l-1)*d)), e, f);
											}
										}
										a = a + c;
									}
									b = b + d;
									a = 0;
								}
							}
							e = e + c + 10;
						}
						f = f + d + 10;
						e = t;
					}
					e = t;
					f = u;
				}
				for( m = 0; m < ligne; m += 1) {
					for (n = 0; n < colonne; n += 1) {
						if (tab[m][n] != tab2[m][n]) {
							compt = 1;
						}
					}
				}
				if (compt == 0) {
					EffacerEcran(CouleurParNom("White"));
					ChargerImage("Victoire.jpg", 350, 250, 0, 0, 850, 335);
					EcrireTexte(1000, 790, "Pour quitter tapez 'q', pour rejouer tapez 'p'", 1);
					p = Touche();
					return p;
				}
				i = -1;
				j = 0;
			}
		}
	} else if (dimx == 1024) {
		ChargerImage("Seatle1.jpg", 20, 200, 0, 0, 372, 199);
		CopierZone(0, 2, 20, 200, 372, 199, 0, 0);

		ChargerImage("Seatle1.jpg", 20, 200, 0, 0, 372, 199);
		EcrireTexte(150, 800, "Nombre de coups : ", 1);
		sprintf(nbr, "%d", coup);
		EcrireTexte(350, 800, nbr, 1);
		for (j = 0; j < ligne; j += 1) {
			for (i = 0; i < colonne; i += 1) {
				if ((tab[j][i] != tab2[j][i]) || (compt = 1)) {
					compt = 0;
					p = Touche();
					if (p == XK_Left) {
						for (m = 0; m < ligne; m += 1) {
							for (n = 0; n < colonne; n += 1) {
								if ((tab[m][n] == 0) && (n != (colonne-1))) {
									tab[m][n] = tab[m][n+1];
									tab[m][n+1] = 0;
									n = n + 1;
									coup += 1;
								}
							}

						}

					} else if (p == XK_Up) {
						for (m = 0; m < ligne; m += 1) {
							for (n = 0; n < colonne; n += 1) {
								if ((tab[m][n] == 0) && (m != (ligne-1))) {
									tab[m][n] = tab[m+1][n];
									tab[m+1][n] = 0;
									m = m + 1;
									coup += 1;
								}
							}
						}
					} else if (p == XK_Right) {
						for (m = 0; m < ligne; m += 1) {
							for (n = 0; n < colonne; n += 1) {
								if ((tab[m][n] == 0) && (n != 0)) {
									tab[m][n] = tab[m][n-1];
									tab[m][n-1] = 0;
									coup += 1;
								}
							}
						}
					} else if (p == XK_Down) {
						for (m = 0; m < ligne; m += 1) {
							for (n = 0; n < colonne; n += 1) {
								if ((tab[m][n] == 0) && (m != 0)) {
									tab[m][n] = tab[m-1][n];
									tab[m-1][n] = 0;
									coup += 1;
								}
							}
						}
					}
					EffacerEcran(CouleurParNom("White"));
					CopierZone(2, 0, 0, 0, 372, 199, 20, 200);
					EcrireTexte(150, 800, "Nombre de coups : ", 1);
					sprintf(nbr, "%d", coup);
					EcrireTexte(350, 800, nbr, 1);
					for( m = 0; m < ligne; m += 1) {
						for (n = 0; n < colonne; n += 1) {
							if (tab[m][n] != 0) {
								a = 0;
								b = 0;
								for (l = 0; l < ligne; l += 1) {
									for (k = 0; k < colonne; k += 1) {
										if (tab[m][n] == tab2[l][k]) {
											if ((k != colonne) && (l != ligne)) {
												CopierZone(1, 0, a, b, c, d, e, f);
											} else if ((k == colonne) && (l != ligne)) {
												CopierZone(1, 0, a, b, (dimx - ((k-1)*c)), d, e, f);
											} else if ((k != colonne) && (l == ligne)) {
												CopierZone(1, 0, a, b, c, (dimy - ((l-1)*d)), e, f);
											} else {
												CopierZone(1, 0, a, b, (dimx - ((k-1)*c)), (dimy - ((l-1)*d)), e, f);
											}
										}
										a = a + c;
									}
									b = b + d;
									a = 0;
								}
							}
							e = e + c + 10;
						}
						f = f + d + 10;
						e = t;
					}
					e = t;
					f = u;
				}
				for( m = 0; m < ligne; m += 1) {
					for (n = 0; n < colonne; n += 1) {
						if (tab[m][n] != tab2[m][n]) {
							compt = 1;
						}
					}
				}
				if (compt == 0) {
					EffacerEcran(CouleurParNom("White"));
					ChargerImage("Victoire.jpg", 350, 250, 0, 0, 850, 335);
					EcrireTexte(1000, 790, "Pour quitter tapez 'q', pour rejouer tapez 'p'", 1);
					p = Touche();
					return p;
				}
				i = -1;
				j = 0;
			}
		}
	} else {
		ChargerImage("Pont1.jpg", 20, 200, 0, 0, 489, 323);
		CopierZone(0, 2, 20, 200, 489, 323, 0, 0);

		ChargerImage("Pont1.jpg", 20, 200, 0, 0, 489, 323);
		EcrireTexte(150, 800, "Nombre de coups : ", 1);
		sprintf(nbr, "%d", coup);
		EcrireTexte(350, 800, nbr, 1);
		for (j = 0; j < ligne; j += 1) {
			for (i = 0; i < colonne; i += 1) {
				if ((tab[j][i] != tab2[j][i]) || (compt = 1)) {
					compt = 0;
					p = Touche();
					if (p == XK_Left) {
						for (m = 0; m < ligne; m += 1) {
							for (n = 0; n < colonne; n += 1) {
								if ((tab[m][n] == 0) && (n != (colonne-1))) {
									tab[m][n] = tab[m][n+1];
									tab[m][n+1] = 0;
									n = n + 1;
									coup += 1;
								}
							}

						}

					} else if (p == XK_Up) {
						for (m = 0; m < ligne; m += 1) {
							for (n = 0; n < colonne; n += 1) {
								if ((tab[m][n] == 0) && (m != (ligne-1))) {
									tab[m][n] = tab[m+1][n];
									tab[m+1][n] = 0;
									m = m + 1;
									coup += 1;
								}
							}
						}
					} else if (p == XK_Right) {
						for (m = 0; m < ligne; m += 1) {
							for (n = 0; n < colonne; n += 1) {
								if ((tab[m][n] == 0) && (n != 0)) {
									tab[m][n] = tab[m][n-1];
									tab[m][n-1] = 0;
									coup += 1;
								}
							}
						}
					} else if (p == XK_Down) {
						for (m = 0; m < ligne; m += 1) {
							for (n = 0; n < colonne; n += 1) {
								if ((tab[m][n] == 0) && (m != 0)) {
									tab[m][n] = tab[m-1][n];
									tab[m-1][n] = 0;
									coup += 1;
								}
							}
						}
					}
					EffacerEcran(CouleurParNom("White"));
					CopierZone(2, 0, 0, 0, 489, 323, 20, 200);
					EcrireTexte(150, 800, "Nombre de coups : ", 1);
					sprintf(nbr, "%d", coup);
					EcrireTexte(350, 800, nbr, 1);
					for( m = 0; m < ligne; m += 1) {
						for (n = 0; n < colonne; n += 1) {
							if (tab[m][n] != 0) {
								a = 0;
								b = 0;
								for (l = 0; l < ligne; l += 1) {
									for (k = 0; k < colonne; k += 1) {
										if (tab[m][n] == tab2[l][k]) {
											if ((k != colonne) && (l != ligne)) {
												CopierZone(1, 0, a, b, c, d, e, f);
											} else if ((k == colonne) && (l != ligne)) {
												CopierZone(1, 0, a, b, (dimx - ((k-1)*c)), d, e, f);
											} else if ((k != colonne) && (l == ligne)) {
												CopierZone(1, 0, a, b, c, (dimy - ((l-1)*d)), e, f);
											} else {
												CopierZone(1, 0, a, b, (dimx - ((k-1)*c)), (dimy - ((l-1)*d)), e, f);
											}
										}
										a = a + c;
									}
									b = b + d;
									a = 0;
								}
							}
							e = e + c + 10;
						}
						f = f + d + 10;
						e = t;
					}
					e = t;
					f = u;
				}
				for( m = 0; m < ligne; m += 1) {
					for (n = 0; n < colonne; n += 1) {
						if (tab[m][n] != tab2[m][n]) {
							compt = 1;
						}
					}
				}
				if (compt == 0) {
					EffacerEcran(CouleurParNom("White"));
					ChargerImage("Victoire.jpg", 350, 250, 0, 0, 850, 335);
					EcrireTexte(1000, 790, "Pour quitter tapez 'q', pour rejouer tapez 'p'", 1);
					p = Touche();
					return p;
				}
				i = -1;
				j = 0;
			}
		}
	}
}
